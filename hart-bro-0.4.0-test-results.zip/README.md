HART-бро 0.4.0: проверенная ревизия 449925012dc1b42463379aa55ef20bf72066f5a4

JVM: 172 / 0 ошибок / 0 пропусков. Android: 16 / 0 ошибок / 0 пропусков.
CI: https://github.com/TomWiskis/HART-bro/actions/runs/41204161337
Android XLSX/PDF и PNG: https://github.com/TomWiskis/HART-bro/actions/runs/41204161337/artifacts/13043959637

Тестовый транспорт отсутствует в основном APK. Аппаратный опыт 0.4.0 ещё предстоит. TEST-ONLY XLSX содержит искусственные приборы. Контрольный Excel с UUID 148d023e основан на реальном пользовательском CSV; бинарный архив реконструирован только для теста.
