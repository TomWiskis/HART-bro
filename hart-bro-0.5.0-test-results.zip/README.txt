HART-бро 0.5.0: 193 JVM + 21 Android tests, zero failures/errors/skips.
Native JUnit/HTML/screenshots remain in the GitHub Actions android-lifecycle-results artifact; its link and count annotation are in validation/android-result.json.
This ZIP contains local JVM XML/Lint plus CI result evidence; no physical hardware write is claimed.
