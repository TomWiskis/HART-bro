# Проверки HART-бро 0.3.0

JVM XML и Lint получены локально для публикуемого кода. GitHub Actions summary и Android annotation подтверждают фактический запуск 11 инструментальных тестов на API 36 без ошибок/пропусков; полный Android JUnit/HTML находится в артефакте android-lifecycle-results этого запуска:
https://github.com/TomWiskis/HART-bro/actions/runs/41074800362

Приложение/модули/workflow выпуска совпадают с проверенным a875fa7e7ca916862625d600247ee48abc66c637; f342aea23fa02fdec86677ba64f574fcf790209a добавляет только документацию. APK подписан прежним сертификатом опубликованной 0.2.1. apk-validation.json содержит SHA-256/размер/проверку package и отсутствия тестовых классов/INTERNET permission.

Android-транспорт синтетический и входит только в androidTest. Работа 0.3.0 с реальным VIATOR/Метраном ещё требует аппаратной проверки по единому плану.
